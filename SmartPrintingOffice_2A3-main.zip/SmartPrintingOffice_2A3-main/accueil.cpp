#include "accueil.h"
#include "ui_accueil.h"
#include "employe.h"
#include "gerer_commande.h"
#include "materiaux.h"
#include "livraison.h"
#include "client.h"
#include "produitmain.h"

accueil::accueil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::accueil)
{
    ui->setupUi(this);
}

accueil::~accueil()
{
    delete ui;
}
void accueil::setData(QString nomU,QString typeU)
{
    if(typeU=="Employe")
    {
        ui->pushButton_employes->hide();
        ui->label_2->setText("Welcome "+nomU);


    }
    else{
         ui->label_2->setText("Welcome "+nomU);
    }
}

void accueil::on_pushButton_employes_clicked()
{
    employe e;
    e.setModal(true);
    e.exec();
}

void accueil::on_pushButton_commandes_clicked()
{
    gerer_commande g_c;
    g_c.setModal(true);
    g_c.exec();
}

void accueil::on_pushButton_materiaux_clicked()
{
    materiaux mat;
    mat.setModal(true);
    mat.exec();
}


void accueil::on_pushButton_livraisons_clicked()
{
    livraison l;
    l.setModal(true);
    l.exec();
}

void accueil::on_pushButton_clients_clicked()
{
    client cl;
    cl.setModal(true);
    cl.exec();
}

void accueil::on_pushButton_produits_clicked()
{
    produitmain pr;
    pr.setModal(true);
    pr.exec();
}
