#ifndef QSOCKET_H
#define QSOCKET_H


class qsocket
{
public:
    qsocket();
};

#endif // QSOCKET_H
