/********************************************************************************
** Form generated from reading UI file 'client.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_client
{
public:
    QTabWidget *tabWidget;
    QWidget *tab_4;
    QLabel *label_cin;
    QLabel *label_nom;
    QLabel *label_prenom;
    QLabel *label_adresse;
    QLabel *label_tel;
    QLineEdit *nomAjout;
    QLineEdit *cinAjout;
    QLineEdit *prenomAjout;
    QLineEdit *telAjout;
    QPushButton *pushButton_3;
    QPushButton *bouton_ajout;
    QLabel *label_image;
    QPushButton *bouton_image;
    QComboBox *comboBox;
    QWidget *widget_2;
    QLabel *label_nom_2;
    QPushButton *bouton_supprimer;
    QPushButton *bouton_PDF;
    QTableView *table_client;
    QGroupBox *groupBox_2;
    QLabel *label_9;
    QLineEdit *cinModif;
    QLabel *label_10;
    QLineEdit *nomModif;
    QLabel *label_11;
    QLineEdit *prenomModif;
    QLabel *label_12;
    QLineEdit *adresseModif;
    QLabel *label_13;
    QLineEdit *numModif;
    QPushButton *bouton_modifier;
    QPushButton *bouton_validerMod;
    QRadioButton *radioButton_croissant;
    QRadioButton *radioButton_decroissant;
    QRadioButton *radioButton_date;
    QGroupBox *groupBox;
    QLabel *label;
    QLineEdit *recherche;
    QWidget *tab;
    QWidget *widget;

    void setupUi(QDialog *client)
    {
        if (client->objectName().isEmpty())
            client->setObjectName(QStringLiteral("client"));
        client->resize(822, 554);
        tabWidget = new QTabWidget(client);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(20, 10, 781, 521));
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        label_cin = new QLabel(tab_4);
        label_cin->setObjectName(QStringLiteral("label_cin"));
        label_cin->setGeometry(QRect(40, 40, 81, 16));
        label_nom = new QLabel(tab_4);
        label_nom->setObjectName(QStringLiteral("label_nom"));
        label_nom->setGeometry(QRect(40, 100, 81, 16));
        label_prenom = new QLabel(tab_4);
        label_prenom->setObjectName(QStringLiteral("label_prenom"));
        label_prenom->setGeometry(QRect(40, 160, 81, 16));
        label_adresse = new QLabel(tab_4);
        label_adresse->setObjectName(QStringLiteral("label_adresse"));
        label_adresse->setGeometry(QRect(40, 220, 101, 16));
        label_tel = new QLabel(tab_4);
        label_tel->setObjectName(QStringLiteral("label_tel"));
        label_tel->setGeometry(QRect(40, 280, 101, 16));
        nomAjout = new QLineEdit(tab_4);
        nomAjout->setObjectName(QStringLiteral("nomAjout"));
        nomAjout->setGeometry(QRect(180, 100, 151, 21));
        nomAjout->setMaxLength(15);
        cinAjout = new QLineEdit(tab_4);
        cinAjout->setObjectName(QStringLiteral("cinAjout"));
        cinAjout->setGeometry(QRect(180, 40, 151, 21));
        cinAjout->setMaxLength(8);
        prenomAjout = new QLineEdit(tab_4);
        prenomAjout->setObjectName(QStringLiteral("prenomAjout"));
        prenomAjout->setGeometry(QRect(180, 160, 151, 21));
        prenomAjout->setMaxLength(8);
        telAjout = new QLineEdit(tab_4);
        telAjout->setObjectName(QStringLiteral("telAjout"));
        telAjout->setGeometry(QRect(180, 280, 151, 21));
        telAjout->setMaxLength(8);
        pushButton_3 = new QPushButton(tab_4);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(370, 380, 75, 24));
        bouton_ajout = new QPushButton(tab_4);
        bouton_ajout->setObjectName(QStringLiteral("bouton_ajout"));
        bouton_ajout->setGeometry(QRect(260, 380, 75, 24));
        label_image = new QLabel(tab_4);
        label_image->setObjectName(QStringLiteral("label_image"));
        label_image->setGeometry(QRect(480, 40, 171, 161));
        bouton_image = new QPushButton(tab_4);
        bouton_image->setObjectName(QStringLiteral("bouton_image"));
        bouton_image->setGeometry(QRect(530, 220, 75, 23));
        comboBox = new QComboBox(tab_4);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(180, 220, 151, 22));
        tabWidget->addTab(tab_4, QString());
        widget_2 = new QWidget();
        widget_2->setObjectName(QStringLiteral("widget_2"));
        label_nom_2 = new QLabel(widget_2);
        label_nom_2->setObjectName(QStringLiteral("label_nom_2"));
        label_nom_2->setGeometry(QRect(40, 100, 81, 16));
        bouton_supprimer = new QPushButton(widget_2);
        bouton_supprimer->setObjectName(QStringLiteral("bouton_supprimer"));
        bouton_supprimer->setGeometry(QRect(560, 320, 75, 24));
        bouton_PDF = new QPushButton(widget_2);
        bouton_PDF->setObjectName(QStringLiteral("bouton_PDF"));
        bouton_PDF->setGeometry(QRect(650, 460, 101, 24));
        table_client = new QTableView(widget_2);
        table_client->setObjectName(QStringLiteral("table_client"));
        table_client->setGeometry(QRect(15, 11, 411, 291));
        groupBox_2 = new QGroupBox(widget_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(460, 10, 251, 291));
        label_9 = new QLabel(groupBox_2);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 20, 47, 14));
        cinModif = new QLineEdit(groupBox_2);
        cinModif->setObjectName(QStringLiteral("cinModif"));
        cinModif->setGeometry(QRect(80, 20, 113, 20));
        label_10 = new QLabel(groupBox_2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 70, 47, 14));
        nomModif = new QLineEdit(groupBox_2);
        nomModif->setObjectName(QStringLiteral("nomModif"));
        nomModif->setGeometry(QRect(80, 70, 113, 20));
        label_11 = new QLabel(groupBox_2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(10, 120, 47, 14));
        prenomModif = new QLineEdit(groupBox_2);
        prenomModif->setObjectName(QStringLiteral("prenomModif"));
        prenomModif->setGeometry(QRect(80, 120, 113, 20));
        label_12 = new QLabel(groupBox_2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(10, 170, 47, 14));
        adresseModif = new QLineEdit(groupBox_2);
        adresseModif->setObjectName(QStringLiteral("adresseModif"));
        adresseModif->setGeometry(QRect(80, 170, 113, 20));
        label_13 = new QLabel(groupBox_2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(10, 220, 61, 16));
        numModif = new QLineEdit(groupBox_2);
        numModif->setObjectName(QStringLiteral("numModif"));
        numModif->setGeometry(QRect(80, 220, 113, 20));
        bouton_modifier = new QPushButton(groupBox_2);
        bouton_modifier->setObjectName(QStringLiteral("bouton_modifier"));
        bouton_modifier->setGeometry(QRect(50, 260, 75, 24));
        bouton_validerMod = new QPushButton(groupBox_2);
        bouton_validerMod->setObjectName(QStringLiteral("bouton_validerMod"));
        bouton_validerMod->setGeometry(QRect(150, 260, 75, 23));
        radioButton_croissant = new QRadioButton(widget_2);
        radioButton_croissant->setObjectName(QStringLiteral("radioButton_croissant"));
        radioButton_croissant->setGeometry(QRect(30, 320, 83, 18));
        radioButton_decroissant = new QRadioButton(widget_2);
        radioButton_decroissant->setObjectName(QStringLiteral("radioButton_decroissant"));
        radioButton_decroissant->setGeometry(QRect(160, 320, 91, 18));
        radioButton_date = new QRadioButton(widget_2);
        radioButton_date->setObjectName(QStringLiteral("radioButton_date"));
        radioButton_date->setGeometry(QRect(280, 320, 141, 18));
        groupBox = new QGroupBox(widget_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(60, 359, 321, 111));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(36, 50, 61, 20));
        recherche = new QLineEdit(groupBox);
        recherche->setObjectName(QStringLiteral("recherche"));
        recherche->setGeometry(QRect(160, 50, 111, 22));
        tabWidget->addTab(widget_2, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        widget = new QWidget(tab);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(60, 60, 641, 371));
        tabWidget->addTab(tab, QString());

        retranslateUi(client);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(client);
    } // setupUi

    void retranslateUi(QDialog *client)
    {
        client->setWindowTitle(QApplication::translate("client", "Dialog", Q_NULLPTR));
        label_cin->setText(QApplication::translate("client", "Cin", Q_NULLPTR));
        label_nom->setText(QApplication::translate("client", "Nom", Q_NULLPTR));
        label_prenom->setText(QApplication::translate("client", "Prenom", Q_NULLPTR));
        label_adresse->setText(QApplication::translate("client", "Adresse", Q_NULLPTR));
        label_tel->setText(QApplication::translate("client", "Numero telephone", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("client", "Annuller", Q_NULLPTR));
        bouton_ajout->setText(QApplication::translate("client", "Ajouter", Q_NULLPTR));
        label_image->setText(QString());
        bouton_image->setText(QApplication::translate("client", "ADD IMAGE", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("client", "tunis", Q_NULLPTR)
         << QApplication::translate("client", "bizerte", Q_NULLPTR)
         << QApplication::translate("client", "kairouan", Q_NULLPTR)
         << QApplication::translate("client", "gafsa", Q_NULLPTR)
         << QApplication::translate("client", "beja", Q_NULLPTR)
         << QApplication::translate("client", "siliana", Q_NULLPTR)
         << QApplication::translate("client", "jendouba", Q_NULLPTR)
         << QApplication::translate("client", "nabeul", Q_NULLPTR)
         << QApplication::translate("client", "ariana", Q_NULLPTR)
         << QApplication::translate("client", "tozeur", Q_NULLPTR)
        );
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("client", "Ajouter client", Q_NULLPTR));
        label_nom_2->setText(QString());
        bouton_supprimer->setText(QApplication::translate("client", "Supprimer", Q_NULLPTR));
        bouton_PDF->setText(QApplication::translate("client", "Export PDF", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("client", "Modifier Client", Q_NULLPTR));
        label_9->setText(QApplication::translate("client", "CIN", Q_NULLPTR));
        label_10->setText(QApplication::translate("client", "Nom", Q_NULLPTR));
        label_11->setText(QApplication::translate("client", "Prenom", Q_NULLPTR));
        label_12->setText(QApplication::translate("client", "Adresse", Q_NULLPTR));
        label_13->setText(QApplication::translate("client", "T\303\251l\303\251phone", Q_NULLPTR));
        bouton_modifier->setText(QApplication::translate("client", "Modifier", Q_NULLPTR));
        bouton_validerMod->setText(QApplication::translate("client", "Valider", Q_NULLPTR));
        radioButton_croissant->setText(QApplication::translate("client", "Tri par nom", Q_NULLPTR));
        radioButton_decroissant->setText(QApplication::translate("client", "Tri par prenom", Q_NULLPTR));
        radioButton_date->setText(QApplication::translate("client", "Tri par date d'inscription", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("client", "Chercher un client", Q_NULLPTR));
        label->setText(QApplication::translate("client", "Recherche", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(widget_2), QApplication::translate("client", "Afficher liste clients", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("client", "statistiques", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class client: public Ui_client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
