#include "mailing.h"

mailing::mailing()
{

}
